# PEPTORYN — Website handoff and launch checklist

## Current state
- Static demonstration storefront (index.html), not a production commerce backend.
- Six catalog items with AED pricing and a client-side currency display.
- No live payment gateway, inventory database, customer authentication, shipping integration or real order processing.
- Do not represent the website as legally cleared to sell research peptides.

## Licensing / regulatory prerequisites
1. Retrieve your Dubai Mainland DET trade license and check the exact activity names/codes.
2. Ask DET whether an amendment is needed for laboratory chemical/research-supply trading and e-commerce.
3. Obtain written UAE product-by-product classification and import/export requirements, including any EDE approvals.
4. Obtain product-by-product UK and Netherlands import and marketing classification reviews before opening checkout for those countries.
5. Verify supplier traceability, batch/lot details, COAs, SDS, storage and transport requirements.
6. Verify buyer eligibility and arrange an approved merchant account; do not activate sales before approvals.

## Technical build priorities
1. Confirm PEPTORYN domain and trademark clearance; set up DNS and HTTPS.
2. Move product data and inventory into a database and add an authenticated admin dashboard.
3. Add buyer verification, country/product checkout restrictions, tax and shipping rules.
4. Integrate a payment provider only after approval for the exact catalog and business model.
5. Add privacy/cookie notices, order emails, refund/shipping policies, logs, backups and security monitoring.
6. Deploy, test on mobile, submit sitemap to search engines and monitor operations.

## Publish the static preview
Upload this ZIP to Netlify Drop or upload index.html to static hosting. This is for a public catalog preview, not an enabled live store.
